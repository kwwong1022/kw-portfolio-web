// home page css hacking
document.querySelector("#WqQANb").innerHTML = '<a href="https://observablehq.com/@kwwong1022/final-project-document">About Web Portrait</a> <a href="https://github.com/kwwong1022/WebPortrait">GitHub Source Code</a>';
document.querySelector("#footer p").innerHTML = '© 2022 - Modified Google Homepage<br>Original Web Page : <a href="www.google.com">google.com</a>';
document.querySelectorAll("a").forEach(a => a.style.color = "rgba(76, 139, 245)");